/*
Project 4: Scanner
James Halladay

Here we are implementing various utility functions
    for a scanner.

*/

#include <iostream>
#include <string>
#include <chrono>
#include <fstream>
#include <vector>
#include <map>

using namespace std;

string strip(string str);